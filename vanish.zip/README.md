# Vanish

A one-time secret note handoff. You send someone a password, an OTP or a bank
detail through a link that works **exactly once** and then destroys itself.

The sender needs an account. The recipient does not.

## How it works

1. Register / login.
2. Compose a note: the secret text, an expiry (say 10 minutes) and a view count (1).
3. The server stores it and hands back a link with a random token, e.g.
   `/vanish/read?t=k7Qm2xR9`.
4. The recipient opens the link and sees the text once.
5. They refresh, and the page says *"This note has been burned."* The secret is gone.
6. The sender's dashboard shows each note's state - unread / burned / expired -
   and the time it was read.
7. Logout invalidates the session, so the dashboard is unreachable, back button included.

The point of the design is that the secret has a lifetime. It is not sitting in a
chat history forever, and the sender can see whether it was ever opened.

## No database

There is no JDBC anywhere in this project, on purpose. Notes live in memory in a
store class (a `ConcurrentHashMap` behind a singleton from Phase 2 onwards). Fewer
moving parts, and short-lived secrets have no business being written to a disk that
outlives them. There is no file save either, for the same reason: a note that
survives a restart is a note that outlived its own expiry.

## Phases

The project is built in four standalone phases. Each one compiles and runs on its
own, so nothing depends on a later phase being finished.

| Phase | Contents |
|-------|----------|
| 1 | Entity classes (`User`, `Note`), constructors and methods, input validation. Console. |
| 2 | Packages `model` / `service` / `store` / `exception`, service interfaces, custom exceptions. Console. |
| 3 | `register.html`, `login.html`, the compose form, shared `style.css`, client-side JS validation, the JSON contract for note creation. |
| 4 | Servlets, JSP dashboard, session handling, burn-on-read on the server. Deployed on Tomcat. |

## Phase 1 (done)

Four programs under `phase1/`. Each sits in its own folder because they all use the
default package and declare the same `User` / `Note` class names.

```
phase1/
  step1_entity/UserEntityDemo.java        entities as plain attributes, assigned and printed
  step2_structure/UserStructureDemo.java  constructors + methods, burn-on-read
  step3_validation/ValidationDemo.java    all input validation, prints every result
  final/VanishPhase1.java                 the deliverable: everything above, end to end
```

`VanishPhase1` runs a scripted walkthrough: three rejected registrations, a failed
login, a successful login, the same login with a padded username, two rejected notes,
three accepted notes, the dashboard, a read, a refresh on the burned link, an expired
note, a guessed token, a second note read once of its two views, and the dashboard again.

### Compile and run

Any one of them, from inside its own folder:

```
javac UserEntityDemo.java
java UserEntityDemo
```

The deliverable:

```
cd phase1/final
javac VanishPhase1.java
java VanishPhase1
```

### Validation rules

| Field | Rule |
|-------|------|
| username | not empty after `trim()`, 3-20 characters, no spaces |
| password | not empty, at least 6 characters |
| confirm password | must `equals()` the password |
| note text | not empty after `trim()`, at most 500 characters |
| expiry | 1 to 1440 minutes |
| views | 1 to 5 |

A username is checked for spaces *after* `trim()`, so `"  student  "` from a padded
form field is accepted and `"win dro"` is not.

### Design notes

- **The secret is never printed outside the read.** `displayNote()` and the dashboard
  row show the link, the status and the timestamps, never the text. The password prints
  masked. Storing and displaying the minimum is the whole ethical argument of the app.
- **`Note` has two constructors.** One takes an expiry in minutes from now, which is the
  real one. The other takes explicit timestamps, which lets the demo plant a note that
  already expired instead of waiting 20 minutes for it.
- **`openLink()` is laid out in exception order.** Its three failure branches - unknown
  token, already burned, expired - are the three exceptions Phase 2 introduces
  (`NoteNotFoundException`, `NoteBurnedException`, `NoteExpiredException`). Same for the
  `return false` branches in `Validator`, which become `InvalidInputException`. Phase 2
  is a conversion, not a rewrite.
- **Tokens are hardcoded strings in Phase 1.** Real tokens come from `SecureRandom` with
  URL-safe Base64 in `NoteService` in Phase 2. A counter or `Math.random()` would let
  anyone walk the notes.
- **`LocalDateTime` for `createdAt` / `expiresAt` / `readAt`,** so `isExpired()` is one
  line and the dashboard can format the stamps.
- **A note has four states, not three.** `status()` returns BURNED, EXPIRED, OPENED or
  UNREAD. OPENED is the views=2..5 case: read at least once, link still alive. Checking
  only `viewsLeft > 0` would have printed UNREAD for a note somebody had already seen.
- **Burning drops the plaintext.** `read()` copies the secret out, then `shred()` sets
  `text` to `null` on the last view. `sweepExpired()` does the same for notes that ran
  out of time unread. A note whose row says BURNED or EXPIRED no longer holds the secret
  anywhere in memory - otherwise the dashboard label is a claim the object contradicts.
- **`maskedPassword()` is fixed width.** `"*".repeat(password.length())` published the
  length of the password, which is free information for anyone guessing it.
- **Register and login agree on the key.** `User` stores `username.trim()`, so
  `findUser()` trims its argument and `login()` compares against the trimmed form. When
  Phase 4 feeds these methods raw form input, a trailing space must not lock the account
  out.

## Phase 2 (done)

One program under `phase2/`, laid out as a source tree because everything is packaged
now.

```
phase2/src/com/vanish/
  model/      User, Note, NoteStatus
  service/    UserService + Impl, NoteService + Impl, Validator
  store/      UserStore, NoteStore, ReadOutcome
  exception/  VanishException and six subclasses
  app/        VanishPhase2 - the console walkthrough
```

No `web` package yet. It would be empty until Phase 4, and an empty package is
scaffolding pretending to be progress.

### Compile and run

From inside `phase2/`:

```
javac -d out $(find src -name '*.java')
java -cp out com.vanish.app.VanishPhase2
```

On Windows, or anywhere without `find`, let `javac` pull in what it needs:

```
javac -sourcepath src -d out src/com/vanish/app/VanishPhase2.java
java -cp out com.vanish.app.VanishPhase2
```

### What changed from Phase 1

- **Validation throws instead of returning false.** Every `return false` in Phase 1's
  `Validator` is now an `InvalidInputException` carrying the field name and the reason.
  Phase 1 printed the reason and lost it; the exception hands it to whoever can act on
  it, and the compiler will not let a caller forget to handle it. The demo's whole
  rejection path is one `catch (VanishException e)`.
- **`openLink()`'s three branches became three exceptions,** exactly as the Phase 1
  comment promised: `NoteNotFoundException`, `NoteBurnedException`, `NoteExpiredException`.
  Two more exist that Phase 1 could not express - `DuplicateUserException` and
  `AuthenticationException`.
- **The burn is atomic.** `NoteStore.read()` does the readable-check and the burn inside a
  single `ConcurrentHashMap.compute()`, which holds the lock for that one token across
  both. Section 11 of the walkthrough fires twenty threads at one one-view note and counts
  how many receive the secret; it prints 1. Running the same twenty threads through a
  plain check-then-act leaks the secret to 2 threads on the first attempt, which is what
  the section is there to catch.
- **Tokens are 32 bytes of `SecureRandom`,** URL-safe Base64, unpadded - 43 characters.
  Phase 1's eight hardcoded strings were a placeholder.
- **Passwords are hashed.** PBKDF2-HMAC-SHA256, 120k iterations, per-user 16-byte salt,
  compared with `MessageDigest.isEqual` so the comparison does not leak how many bytes
  matched. The plaintext never becomes a field of `User`.
- **Registration claims the name atomically.** `putIfAbsent` decides, so two simultaneous
  registrations of one username cannot both succeed. Phase 1 scanned a list and then
  added.
- **`NoteStatus` is an enum, not a string.** Four states, closed set, and
  `isFinished()` is what the audit checks against.

### Design notes

- **`Note` is deliberately not thread safe.** `read()` is check-then-act and says so in
  its Javadoc. The store owns the atomicity because the store owns the lock; a second
  `synchronized` inside `Note` would be a second answer to a question that already has
  one, and it would not help - the race spans two calls, not one.
- **The store returns a `ReadOutcome`, not an exception.** `compute()`'s remapping
  function cannot throw checked exceptions, and throwing while holding a bin lock is a
  bad habit regardless. The store reports a verdict; `NoteServiceImpl` translates it.
- **Section 13 audits the invariant** rather than asserting it in a comment: after
  everything above has run, no note whose status `isFinished()` still holds plaintext.
  That is the one property the product is named after, so the demo proves it rather than
  claiming it.
- **`authenticate` gives one error for both halves.** A distinct "no such user" would
  confirm which usernames exist.
- **Password validation does not trim.** Leading and trailing spaces are legitimate
  password characters; silently dropping them would lock a user out of the account they
  thought they made. Usernames do trim, because they are a lookup key.

## Toolchain

- **JDK 17** (Eclipse Temurin 17.0.20). Phases 1 and 2 need nothing else - no build tool,
  no dependencies, plain `javac`.
- **Tomcat 9.0.x** for Phase 4, not the newest release. Tomcat 9 uses `javax.servlet.*`;
  Tomcat 10.1 and 11 renamed it to `jakarta.servlet.*`. Every course reference is javax,
  so match whatever the lab machines run, and check this before writing Phase 4.

## Still open for Phase 4

Two of the four decisions recorded here earlier are now built - the atomic burn and the
password hashing both landed in Phase 2. What is left changes the servlet mapping and the
markup, so it has to be settled before Phase 3 draws the read page.

- **GET renders, POST burns.** A GET that destroys the note is destroyed *for* you:
  Slack, WhatsApp, Teams, Outlook Safe Links and endpoint antivirus all fetch a URL to
  build a preview or scan it, so the messenger burns the secret in transit and the
  recipient's first click shows "This note has been burned." So `GET /vanish/read?t=`
  renders a page with a Reveal button and touches no state; the burn happens on the POST
  behind that button, served with `Cache-Control: no-store`. This also keeps GET a safe
  method, which is what HTTP promises. `VanishPhase2.open()` is the two halves still
  joined; the comment above it marks the seam.
- **Sweeping needs a timer.** `NoteStore.sweepExpired()` currently runs whenever the
  dashboard is listed, which is enough for a console demo but means an expired note that
  nobody looks at keeps its plaintext until somebody does. Phase 4 has a
  `ServletContextListener`, so that is where a scheduled sweep belongs.
- **The dashboard is as sensitive as the notes.** `dashboardRow()` truncates the token for
  the console, but the sender's real dashboard has to show the whole share link or it is
  useless - so a leaked dashboard is a leaked set of live links. Phase 4's session
  handling is load-bearing, not a checkbox.
