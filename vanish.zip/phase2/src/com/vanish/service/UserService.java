package com.vanish.service;

import com.vanish.exception.AuthenticationException;
import com.vanish.exception.DuplicateUserException;
import com.vanish.exception.InvalidInputException;
import com.vanish.model.User;

/**
 * User operations: validation and authentication.
 *
 * This is the interface the Phase 2 brief asks for. It exists so that the caller
 * - a console demo now, a servlet in Phase 4 - is written against the operations
 * and not against the in-memory map that happens to implement them today. If the
 * store is ever swapped, this file does not change.
 *
 * Every method that can reject its input says so in its signature. The compiler
 * then forces the caller to decide what the user sees, which is the whole reason
 * for preferring checked exceptions over the boolean returns of Phase 1.
 */
public interface UserService {

    /**
     * Validate, then claim the username.
     *
     * @return the created account
     * @throws InvalidInputException  a field is empty, too short, too long or the
     *                                confirmation does not match
     * @throws DuplicateUserException the username is taken
     */
    User register(String username, String password, String confirmPassword)
            throws InvalidInputException, DuplicateUserException;

    /**
     * Check a username and password pair.
     *
     * @return the account
     * @throws AuthenticationException the pair does not match an account. One
     *                                 exception for both halves, deliberately: a
     *                                 distinct "no such user" would confirm which
     *                                 usernames exist.
     */
    User authenticate(String username, String password) throws AuthenticationException;

    /**
     * @return true if the username is already claimed. For a live form check;
     *         never as a guard before {@link #register}, which does its own
     *         atomic claim.
     */
    boolean exists(String username);
}
