package com.vanish.service;

import com.vanish.exception.InvalidInputException;

/**
 * Every input rule in one place, as the Phase 2 conversion of Phase 1's
 * {@code Validator}.
 *
 * Phase 1 printed a reason and returned false, which meant the caller had to
 * remember to check and the reason was already gone by the time anyone could use
 * it. Each of those branches is now a thrown {@link InvalidInputException}
 * carrying the field name and the reason, so a servlet can put the message back
 * on the form beside the field that caused it and a missed check is a compile
 * error rather than a silently accepted value.
 *
 * The methods return the cleaned value where there is one, so a caller cannot
 * validate the trimmed form and then store the raw one.
 */
public final class Validator {

    public static final int MIN_USERNAME_LENGTH = 3;
    public static final int MAX_USERNAME_LENGTH = 20;
    public static final int MIN_PASSWORD_LENGTH = 6;
    public static final int MAX_NOTE_LENGTH = 500;
    public static final int MIN_EXPIRY_MINUTES = 1;
    public static final int MAX_EXPIRY_MINUTES = 1440;   // 24 hours
    public static final int MIN_VIEWS = 1;
    public static final int MAX_VIEWS = 5;

    private Validator() {
    }

    /**
     * @return the trimmed username, which is what the store keys on
     */
    public static String username(String username) throws InvalidInputException {
        if (username == null || username.trim().isEmpty()) {
            throw new InvalidInputException("username", "username cannot be empty");
        }
        String clean = username.trim();
        if (clean.length() < MIN_USERNAME_LENGTH) {
            throw new InvalidInputException("username",
                    "username must be at least " + MIN_USERNAME_LENGTH + " characters");
        }
        if (clean.length() > MAX_USERNAME_LENGTH) {
            throw new InvalidInputException("username",
                    "username cannot be longer than " + MAX_USERNAME_LENGTH + " characters");
        }
        // Checked after trimming, so a padded form field is accepted and an
        // embedded space is not. Phase 1 checked the raw string and rejected
        // "  student  " for containing a space it had already agreed to ignore.
        if (clean.contains(" ")) {
            throw new InvalidInputException("username", "username cannot contain spaces");
        }
        return clean;
    }

    /**
     * Not trimmed: leading and trailing spaces are legitimate password
     * characters, and silently removing them would lock the user out of the
     * account they thought they created.
     */
    public static String password(String password) throws InvalidInputException {
        if (password == null || password.isEmpty()) {
            throw new InvalidInputException("password", "password cannot be empty");
        }
        if (password.length() < MIN_PASSWORD_LENGTH) {
            throw new InvalidInputException("password",
                    "password must be at least " + MIN_PASSWORD_LENGTH + " characters");
        }
        return password;
    }

    public static void passwordsMatch(String password, String confirmPassword) throws InvalidInputException {
        if (confirmPassword == null || !confirmPassword.equals(password)) {
            throw new InvalidInputException("confirmPassword", "the two passwords do not match");
        }
    }

    /**
     * @return the trimmed secret
     */
    public static String noteText(String text) throws InvalidInputException {
        if (text == null || text.trim().isEmpty()) {
            throw new InvalidInputException("text", "the note cannot be empty");
        }
        String clean = text.trim();
        if (clean.length() > MAX_NOTE_LENGTH) {
            throw new InvalidInputException("text",
                    "the note cannot be longer than " + MAX_NOTE_LENGTH + " characters");
        }
        return clean;
    }

    public static int expiryMinutes(int minutes) throws InvalidInputException {
        if (minutes < MIN_EXPIRY_MINUTES || minutes > MAX_EXPIRY_MINUTES) {
            throw new InvalidInputException("expiryMinutes",
                    "expiry must be between " + MIN_EXPIRY_MINUTES + " and " + MAX_EXPIRY_MINUTES + " minutes");
        }
        return minutes;
    }

    public static int views(int views) throws InvalidInputException {
        if (views < MIN_VIEWS || views > MAX_VIEWS) {
            throw new InvalidInputException("views",
                    "views must be between " + MIN_VIEWS + " and " + MAX_VIEWS);
        }
        return views;
    }
}
