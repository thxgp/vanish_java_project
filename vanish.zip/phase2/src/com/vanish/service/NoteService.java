package com.vanish.service;

import java.util.List;

import com.vanish.exception.InvalidInputException;
import com.vanish.exception.NoteBurnedException;
import com.vanish.exception.NoteExpiredException;
import com.vanish.exception.NoteNotFoundException;
import com.vanish.model.Note;
import com.vanish.model.User;

/**
 * Note operations: compose, read once, list.
 *
 * The counterpart to {@link UserService}. Phase 1's {@code openLink()} had its
 * three failure branches written in this order for exactly this reason - each one
 * is now a declared exception.
 */
public interface NoteService {

    /**
     * Validate and store a note, with a freshly generated token.
     *
     * @throws InvalidInputException the text is empty or too long, or the expiry
     *                               or view count is out of range
     */
    Note create(User owner, String text, int expiryMinutes, int views) throws InvalidInputException;

    /**
     * Spend one view and return the secret.
     *
     * Destructive by design: on the last view the note burns and the plaintext is
     * dropped before this method returns. Calling it twice on a one-view note
     * throws the second time, which is the product working.
     *
     * @return the secret, the only copy the caller will get
     * @throws NoteNotFoundException no note under that token
     * @throws NoteBurnedException   already read to exhaustion
     * @throws NoteExpiredException  out of time
     */
    String read(String token) throws NoteNotFoundException, NoteBurnedException, NoteExpiredException;

    /** The sender's notes, newest first. Never carries plaintext to the caller. */
    List<Note> listFor(User owner);
}
