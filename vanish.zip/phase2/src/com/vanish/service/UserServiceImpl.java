package com.vanish.service;

import com.vanish.exception.AuthenticationException;
import com.vanish.exception.DuplicateUserException;
import com.vanish.exception.InvalidInputException;
import com.vanish.model.User;
import com.vanish.store.UserStore;

/**
 * {@link UserService} backed by {@link UserStore}.
 *
 * Thin on purpose: validate, hash, claim. The hashing lives in the User
 * constructor and the atomicity lives in the store, so there is nothing left
 * here but the order of operations.
 */
public class UserServiceImpl implements UserService {

    private final UserStore store;

    public UserServiceImpl() {
        this(UserStore.getInstance());
    }

    /** Takes the store so a test can hand in its own. */
    public UserServiceImpl(UserStore store) {
        this.store = store;
    }

    @Override
    public User register(String username, String password, String confirmPassword)
            throws InvalidInputException, DuplicateUserException {

        String cleanUsername = Validator.username(username);
        Validator.password(password);
        Validator.passwordsMatch(password, confirmPassword);

        User user = new User(cleanUsername, password);

        // No "is it taken?" check before this. The claim itself decides, so two
        // simultaneous registrations of the same name cannot both succeed.
        if (!store.add(user)) {
            throw new DuplicateUserException(cleanUsername);
        }
        return user;
    }

    @Override
    public User authenticate(String username, String password) throws AuthenticationException {
        User user = store.find(username);
        // Same exception either way, so the caller cannot tell a wrong password
        // from a username that does not exist.
        if (user == null || !user.verify(password)) {
            throw new AuthenticationException();
        }
        return user;
    }

    @Override
    public boolean exists(String username) {
        return store.find(username) != null;
    }
}
