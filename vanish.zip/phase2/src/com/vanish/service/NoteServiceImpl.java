package com.vanish.service;

import java.security.SecureRandom;
import java.util.Base64;
import java.util.List;

import com.vanish.exception.InvalidInputException;
import com.vanish.exception.NoteBurnedException;
import com.vanish.exception.NoteExpiredException;
import com.vanish.exception.NoteNotFoundException;
import com.vanish.model.Note;
import com.vanish.model.User;
import com.vanish.store.NoteStore;
import com.vanish.store.ReadOutcome;

/**
 * {@link NoteService} backed by {@link NoteStore}.
 *
 * Owns token generation and the translation of the store's {@link ReadOutcome}
 * into the three exceptions the read page distinguishes.
 */
public class NoteServiceImpl implements NoteService {

    /**
     * 32 bytes. The token is the only thing standing between a stranger and the
     * secret, so it gets a full 256 bits rather than a length that merely looks
     * random. Phase 1's eight hardcoded characters were a placeholder, and a
     * counter or Math.random() would let anyone walk the notes.
     */
    private static final int TOKEN_BYTES = 32;

    private static final SecureRandom RANDOM = new SecureRandom();

    /** URL-safe and unpadded, because the token is going in a query string. */
    private static final Base64.Encoder ENCODER = Base64.getUrlEncoder().withoutPadding();

    private final NoteStore store;

    public NoteServiceImpl() {
        this(NoteStore.getInstance());
    }

    /** Takes the store so a test can hand in its own. */
    public NoteServiceImpl(NoteStore store) {
        this.store = store;
    }

    @Override
    public Note create(User owner, String text, int expiryMinutes, int views) throws InvalidInputException {
        String cleanText = Validator.noteText(text);
        Validator.expiryMinutes(expiryMinutes);
        Validator.views(views);

        Note note = new Note(store.nextId(), newToken(), owner.getUsername(), cleanText, expiryMinutes, views);
        if (!store.add(note)) {
            // 256 random bits collided. Treated as impossible rather than
            // retried, because a silent retry would hide a broken RANDOM.
            throw new IllegalStateException("token collision");
        }
        return note;
    }

    @Override
    public String read(String token) throws NoteNotFoundException, NoteBurnedException, NoteExpiredException {
        ReadOutcome outcome = store.read(token);
        switch (outcome.getKind()) {
            case OK:
                return outcome.getSecret();
            case BURNED:
                throw new NoteBurnedException();
            case EXPIRED:
                throw new NoteExpiredException();
            default:
                throw new NoteNotFoundException();
        }
    }

    @Override
    public List<Note> listFor(User owner) {
        return store.findByOwner(owner.getUsername());
    }

    private static String newToken() {
        byte[] bytes = new byte[TOKEN_BYTES];
        RANDOM.nextBytes(bytes);
        return ENCODER.encodeToString(bytes);
    }
}
