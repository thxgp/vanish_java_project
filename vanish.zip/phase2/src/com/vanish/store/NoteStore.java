package com.vanish.store;

import java.util.ArrayList;
import java.util.Comparator;
import java.util.List;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.atomic.AtomicInteger;

import com.vanish.model.Note;

/**
 * The note store: a {@link ConcurrentHashMap} keyed by token, and the one place
 * that is allowed to perform a read.
 *
 * There is no JDBC here on purpose - see the README. A short-lived secret has no
 * business being written to a disk that outlives it.
 *
 * The load-bearing method is {@link #read(String)}. Everything else is
 * bookkeeping.
 */
public final class NoteStore {

    private static final NoteStore INSTANCE = new NoteStore();

    private final ConcurrentHashMap<String, Note> notes = new ConcurrentHashMap<>();
    private final AtomicInteger nextId = new AtomicInteger(1);

    private NoteStore() {
    }

    public static NoteStore getInstance() {
        return INSTANCE;
    }

    /** Ids are only for display, but two threads composing at once must not share one. */
    public int nextId() {
        return nextId.getAndIncrement();
    }

    /**
     * @return false if the token is somehow already in use. With 256 bits of
     *         SecureRandom this will not happen; it is checked rather than
     *         assumed because the cost of being wrong is one secret overwriting
     *         another.
     */
    public boolean add(Note note) {
        return notes.putIfAbsent(note.getToken(), note) == null;
    }

    /**
     * Read a token: the entire check-and-burn, atomically.
     *
     * {@code compute} holds the lock for this one key across the whole lambda, so
     * the {@code isReadable} test and the {@code read} that follows cannot be
     * split by another thread. Two simultaneous requests for a one-view note
     * therefore produce exactly one OK and one BURNED - which is the promise the
     * product is named after. A plain {@code get} followed by {@code read} would
     * hand the same secret to both, and no amount of ConcurrentHashMap fixes
     * that, because the race is in the caller and not in the map.
     *
     * The lambda mutates the note in place and returns it, so the mapping stays.
     * Expired notes are kept, with their plaintext dropped, so the sender's
     * dashboard can still show that the note was never opened. The sweeper is
     * what eventually removes them.
     */
    public ReadOutcome read(String token) {
        if (token == null) {
            return ReadOutcome.notFound();
        }

        // One slot, written inside the lambda, read after compute returns. Not
        // shared with any other thread: compute's lambda runs on this one.
        String[] secret = new String[1];
        ReadOutcome.Kind[] kind = {ReadOutcome.Kind.NOT_FOUND};

        notes.compute(token, (key, note) -> {
            if (note == null) {
                kind[0] = ReadOutcome.Kind.NOT_FOUND;
                return null;
            }
            if (note.isBurned()) {
                kind[0] = ReadOutcome.Kind.BURNED;
                return note;
            }
            if (note.isExpired()) {
                note.expireIfDue();
                kind[0] = ReadOutcome.Kind.EXPIRED;
                return note;
            }
            secret[0] = note.read();
            kind[0] = ReadOutcome.Kind.OK;
            return note;
        });

        switch (kind[0]) {
            case OK:
                return ReadOutcome.ok(secret[0]);
            case BURNED:
                return ReadOutcome.burned();
            case EXPIRED:
                return ReadOutcome.expired();
            default:
                return ReadOutcome.notFound();
        }
    }

    /**
     * The sender's own notes, newest first.
     *
     * Sweeps first, so a row can never say EXPIRED while the note still holds the
     * plaintext. Phase 4 moves this onto a timer; running it here means the
     * console demo needs no scheduler.
     */
    public List<Note> findByOwner(String owner) {
        sweepExpired();
        List<Note> mine = new ArrayList<>();
        for (Note note : notes.values()) {
            if (note.getOwner().equals(owner)) {
                mine.add(note);
            }
        }
        mine.sort(Comparator.comparing(Note::getCreatedAt).reversed());
        return mine;
    }

    /**
     * Drop the plaintext of every note past its expiry.
     *
     * @return how many secrets this call actually cleared
     */
    public int sweepExpired() {
        int cleared = 0;
        for (Note note : notes.values()) {
            if (note.expireIfDue()) {
                cleared++;
            }
        }
        return cleared;
    }

    public int count() {
        return notes.size();
    }

    /** True while any stored note still holds a secret. Used by the demo's audit. */
    public boolean anyHoldsSecret() {
        for (Note note : notes.values()) {
            if (note.holdsSecret()) {
                return true;
            }
        }
        return false;
    }
}
