package com.vanish.store;

/**
 * What happened when somebody tried to read a token, decided inside the store's
 * atomic region and reported back out of it.
 *
 * The store cannot throw {@code NoteBurnedException} from inside a
 * {@code ConcurrentHashMap.compute} lambda - the functional interface does not
 * declare checked exceptions, and throwing from a remapping function while the
 * bin lock is held is a bad habit besides. So the store returns a verdict and
 * the service turns it into the exception the caller sees.
 */
public final class ReadOutcome {

    public enum Kind {
        /** The secret is in {@link #getSecret()} and is now spent. */
        OK,
        /** No note under that token. */
        NOT_FOUND,
        /** Read to exhaustion already. */
        BURNED,
        /** Out of time. */
        EXPIRED
    }

    // The three failures carry nothing, so they are shared rather than allocated
    // on every miss.
    private static final ReadOutcome NOT_FOUND = new ReadOutcome(Kind.NOT_FOUND, null);
    private static final ReadOutcome BURNED = new ReadOutcome(Kind.BURNED, null);
    private static final ReadOutcome EXPIRED = new ReadOutcome(Kind.EXPIRED, null);

    private final Kind kind;
    private final String secret;

    private ReadOutcome(Kind kind, String secret) {
        this.kind = kind;
        this.secret = secret;
    }

    public static ReadOutcome ok(String secret) {
        return new ReadOutcome(Kind.OK, secret);
    }

    public static ReadOutcome notFound() {
        return NOT_FOUND;
    }

    public static ReadOutcome burned() {
        return BURNED;
    }

    public static ReadOutcome expired() {
        return EXPIRED;
    }

    public Kind getKind() {
        return kind;
    }

    /** The plaintext, only when {@link #getKind()} is OK. */
    public String getSecret() {
        return secret;
    }
}
