package com.vanish.store;

import java.util.concurrent.ConcurrentHashMap;

import com.vanish.model.User;

/**
 * The account store: the only place a {@link User} lives.
 *
 * A singleton because Phase 4 has one store per web application, reached from
 * servlets that are themselves single instances shared across request threads.
 * The instance is a static final field, so class initialisation does the
 * publishing and there is no lazy-init locking to get wrong.
 *
 * The map key is the trimmed username, and every lookup trims its argument. Phase
 * 1's bug was register storing a trimmed name while login searched for the raw
 * one, which locked the account out the moment a form field carried a space.
 * Keeping the trim in the store means there is one place to be right.
 */
public final class UserStore {

    private static final UserStore INSTANCE = new UserStore();

    private final ConcurrentHashMap<String, User> users = new ConcurrentHashMap<>();

    private UserStore() {
    }

    public static UserStore getInstance() {
        return INSTANCE;
    }

    /**
     * Claim a username.
     *
     * @return false when it is already taken. {@code putIfAbsent} decides this
     *         atomically; Phase 1 scanned a list and then added, so two
     *         simultaneous registrations could both find the name free.
     */
    public boolean add(User user) {
        return users.putIfAbsent(user.getUsername(), user) == null;
    }

    /** @return the account, or null. */
    public User find(String username) {
        return username == null ? null : users.get(username.trim());
    }

    public int count() {
        return users.size();
    }
}
