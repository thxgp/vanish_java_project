package com.vanish.exception;

/**
 * The note existed and has already been read to exhaustion. The plaintext is
 * gone, not withheld.
 *
 * This is the message that proves the product works, so it stays distinct from
 * {@link NoteNotFoundException} for the recipient. The tradeoff: telling an
 * attacker "burned" rather than "no such note" confirms the token was real.
 * Acceptable, because the secret is already destroyed by the time they see it,
 * and the sender needs the recipient to understand what happened.
 */
public class NoteBurnedException extends VanishException {

    private static final long serialVersionUID = 1L;

    public NoteBurnedException() {
        super("this note has been burned");
    }
}
