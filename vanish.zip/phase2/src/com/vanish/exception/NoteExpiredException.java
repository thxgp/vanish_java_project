package com.vanish.exception;

/**
 * The note ran out of time before anybody opened it. The plaintext is dropped at
 * the moment this is thrown, so the state and the storage agree.
 */
public class NoteExpiredException extends VanishException {

    private static final long serialVersionUID = 1L;

    public NoteExpiredException() {
        super("this note has expired");
    }
}
