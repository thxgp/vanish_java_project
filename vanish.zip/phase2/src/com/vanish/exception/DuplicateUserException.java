package com.vanish.exception;

/**
 * Someone tried to register a username that already exists.
 *
 * Separate from {@link InvalidInputException} because the input was well formed;
 * it lost a race or collided with an existing account. Phase 1 checked this with
 * a list scan followed by an add, which two simultaneous registrations could
 * both pass. Phase 2 gets it from {@code ConcurrentHashMap.putIfAbsent}.
 */
public class DuplicateUserException extends VanishException {

    private static final long serialVersionUID = 1L;

    public DuplicateUserException(String username) {
        super("the username '" + username + "' is already taken");
    }
}
