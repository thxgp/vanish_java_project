package com.vanish.exception;

/**
 * Base class for everything Vanish throws on purpose.
 *
 * Checked, not runtime, so the compiler forces every caller to decide what the
 * page should say. Each subclass maps to exactly one message the user sees, and
 * in Phase 4 to one JSP or one HTTP status.
 */
public class VanishException extends Exception {

    private static final long serialVersionUID = 1L;

    public VanishException(String message) {
        super(message);
    }
}
