package com.vanish.exception;

/**
 * A field the user typed failed validation.
 *
 * This is the Phase 2 replacement for every {@code return false} in Phase 1's
 * Validator. The message is the reason, written for the person who typed it, so
 * a servlet can put it straight back on the form.
 */
public class InvalidInputException extends VanishException {

    private static final long serialVersionUID = 1L;

    private final String field;

    public InvalidInputException(String field, String message) {
        super(message);
        this.field = field;
    }

    /** Which form field to highlight. */
    public String getField() {
        return field;
    }
}
