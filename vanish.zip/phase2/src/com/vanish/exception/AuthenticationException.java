package com.vanish.exception;

/**
 * The username/password pair did not match an account.
 *
 * Deliberately says nothing about which half was wrong. Telling the caller "no
 * such user" confirms which usernames exist, which is free reconnaissance.
 */
public class AuthenticationException extends VanishException {

    private static final long serialVersionUID = 1L;

    public AuthenticationException() {
        super("invalid username or password");
    }
}
