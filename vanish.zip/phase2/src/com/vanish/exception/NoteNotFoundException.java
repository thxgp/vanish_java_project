package com.vanish.exception;

/**
 * No note is stored under that token: a typo, a guess, or a link so old the
 * note has already been swept.
 *
 * The message is identical in spirit to {@link NoteBurnedException} on purpose
 * at the HTTP layer - see the note there.
 */
public class NoteNotFoundException extends VanishException {

    private static final long serialVersionUID = 1L;

    public NoteNotFoundException() {
        super("invalid link, no such note");
    }
}
