package com.vanish.app;

import java.time.LocalDateTime;
import java.util.Collections;
import java.util.List;
import java.util.concurrent.Callable;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.Future;

import com.vanish.exception.VanishException;
import com.vanish.model.Note;
import com.vanish.model.User;
import com.vanish.service.NoteService;
import com.vanish.service.NoteServiceImpl;
import com.vanish.service.UserService;
import com.vanish.service.UserServiceImpl;
import com.vanish.store.NoteStore;

/**
 * VANISH - Phase 2 console walkthrough.
 *
 * Same story as Phase 1, told through the packaged service layer: every rejection
 * is now a caught exception rather than a printed line and a false return, tokens
 * come from SecureRandom, and the store is a ConcurrentHashMap singleton.
 *
 * Two sections exist that Phase 1 could not have: a concurrency check that proves
 * one secret cannot be read twice, and an audit that proves no finished note is
 * still holding its plaintext.
 */
public class VanishPhase2 {

    private static final UserService users = new UserServiceImpl();
    private static final NoteService notes = new NoteServiceImpl();

    public static void main(String[] args) throws Exception {

        System.out.println("=========================================");
        System.out.println("  VANISH  -  Phase 2 console walkthrough ");
        System.out.println("=========================================");

        heading("1. REGISTRATION");
        register("ab", "java123", "java123");
        register("student", "123", "123");
        register("student", "java123", "java1234");
        register("win dro", "java123", "java123");
        register("student", "java123", "java123");
        register("student", "meow123", "meow123");

        heading("2. LOGIN");
        login("student", "wrongpass");
        login("nosuchuser", "java123");
        User user = login("student", "java123");
        login("  student  ", "java123");

        heading("3. LOGGED IN USER");
        System.out.println("Username   : " + user.getUsername());
        System.out.println("Password   : " + user.maskedPassword());
        System.out.println("Registered : " + user.getRegisteredAt());

        heading("4. COMPOSING NOTES");
        compose(user, "   ", 10, 1);
        compose(user, "atm pin 4821", 5000, 1);
        compose(user, "atm pin 4821", 10, 9);
        Note first = compose(user, "atm pin 4821", 10, 1);
        compose(user, "wifi password meow@2026", 60, 1);
        Note twoViews = compose(user, "locker code 77-12-04", 30, 2);

        // An already-expired note, built with the overloaded constructor and put
        // straight into the store. Waiting out a real expiry would take minutes.
        Note stale = new Note(NoteStore.getInstance().nextId(), "expiredDemoToken", user.getUsername(),
                "old exam seat number",
                LocalDateTime.now().minusMinutes(30), LocalDateTime.now().minusMinutes(20), 1);
        NoteStore.getInstance().add(stale);

        heading("5. DASHBOARD BEFORE ANYBODY READS");
        dashboard(user);

        heading("6. RECIPIENT OPENS THE LINK");
        open(first.getToken());

        heading("7. RECIPIENT REFRESHES THE PAGE");
        open(first.getToken());

        heading("8. SOMEONE OPENS THE EXPIRED NOTE");
        open(stale.getToken());

        heading("9. SOMEONE GUESSES A TOKEN");
        open("zzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzz");

        heading("10. A NOTE WITH TWO VIEWS, OPENED ONCE");
        open(twoViews.getToken());

        heading("11. TWENTY THREADS RACE FOR ONE ONE-VIEW NOTE");
        race(user);

        heading("12. DASHBOARD AFTER THE READS");
        dashboard(user);

        heading("13. AUDIT : DOES ANY FINISHED NOTE STILL HOLD ITS SECRET?");
        audit();

        System.out.println();
        System.out.println("Phase 2 complete : packages, service interfaces, exception handling.");
    }

    // ---------- accounts ----------

    private static void register(String username, String password, String confirmPassword) {
        System.out.println("register : username=[" + username + "] password=[" + mask(password)
                + "] confirm=[" + mask(confirmPassword) + "]");
        try {
            User created = users.register(username, password, confirmPassword);
            System.out.println("  accepted : account created for " + created.getUsername());
        } catch (VanishException e) {
            // One catch for every rejection: the exception hierarchy is what
            // makes this a single branch instead of six boolean checks.
            System.out.println("  rejected : " + e.getMessage());
        }
    }

    private static User login(String username, String password) {
        System.out.println("login : username=[" + username + "] password=[" + mask(password) + "]");
        try {
            User user = users.authenticate(username, password);
            System.out.println("  ok : welcome back, " + user.getUsername());
            return user;
        } catch (VanishException e) {
            System.out.println("  failed : " + e.getMessage());
            return null;
        }
    }

    // ---------- notes ----------

    private static Note compose(User owner, String text, int expiryMinutes, int views) {
        System.out.println("compose : expiry=" + expiryMinutes + "min views=" + views
                + " length=" + (text == null ? 0 : text.length()));
        try {
            Note note = notes.create(owner, text, expiryMinutes, views);
            System.out.println("  accepted : note #" + note.getId() + " created");
            System.out.println("  link     : " + note.shareLink());
            return note;
        } catch (VanishException e) {
            System.out.println("  rejected : " + e.getMessage());
            return null;
        }
    }

    /**
     * The public read page.
     *
     * Phase 4 splits this in two: GET renders a page with a Reveal button and
     * changes nothing, POST does this. A GET that destroys the secret gets tripped
     * by link preview bots and virus scanners, which fetch the URL before the
     * recipient ever clicks it.
     */
    private static void open(String token) {
        System.out.println("GET /vanish/read?t=" + shortToken(token));
        try {
            String secret = notes.read(token);
            System.out.println("  page shows : " + secret);
            // The service hands back the secret and nothing else, so the page
            // cannot claim the link is dead - a two-view note still has one left.
            // Phase 4 shows the remaining count to the sender, not the recipient.
            System.out.println("  page shows : that view has been spent");
        } catch (VanishException e) {
            System.out.println("  page shows : " + e.getMessage());
        }
    }

    private static void dashboard(User owner) {
        System.out.println("dashboard of " + owner.getUsername());
        List<Note> mine = notes.listFor(owner);
        if (mine.isEmpty()) {
            System.out.println("  no notes yet");
            return;
        }
        for (Note note : mine) {
            System.out.println(note.dashboardRow());
        }
    }

    // ---------- the two checks Phase 1 could not make ----------

    /**
     * Twenty threads, one note, one view. Exactly one must get the secret.
     *
     * This is the section that justifies the atomic read in NoteStore. With a
     * plain get-then-read the count comes out above one on a multi-core machine,
     * and every extra OK is a secret delivered twice.
     */
    private static void race(User owner) throws Exception {
        final int threads = 20;
        Note prize = notes.create(owner, "race condition secret", 10, 1);

        ExecutorService pool = Executors.newFixedThreadPool(threads);
        try {
            Callable<Boolean> attempt = () -> {
                try {
                    notes.read(prize.getToken());
                    return true;
                } catch (VanishException e) {
                    return false;
                }
            };

            List<Future<Boolean>> results = pool.invokeAll(Collections.nCopies(threads, attempt));
            int gotIt = 0;
            for (Future<Boolean> result : results) {
                if (result.get()) {
                    gotIt++;
                }
            }

            System.out.println("  " + threads + " threads read the same one-view token");
            System.out.println("  threads that received the secret : " + gotIt);
            System.out.println("  " + (gotIt == 1 ? "PASS : the burn is atomic" : "FAIL : the secret leaked " + gotIt + " times"));
        } finally {
            pool.shutdown();
        }
    }

    /**
     * The invariant the whole product rests on: a note whose status is finished
     * holds no plaintext.
     */
    private static void audit() {
        NoteStore store = NoteStore.getInstance();
        store.sweepExpired();

        int holding = 0;
        for (Note note : store.findByOwner("student")) {
            if (note.getStatus().isFinished() && note.holdsSecret()) {
                System.out.println("  LEAK : " + note);
                holding++;
            }
        }
        System.out.println("  notes stored : " + store.count());
        System.out.println("  " + (holding == 0
                ? "PASS : every burned or expired note has dropped its plaintext"
                : "FAIL : " + holding + " finished note(s) still hold a secret"));
    }

    // ---------- output helpers ----------

    private static void heading(String title) {
        System.out.println();
        System.out.println("===== " + title + " =====");
    }

    /** Passwords are never printed, and never at their real length. */
    private static String mask(String password) {
        return password == null ? "null" : "********";
    }

    /** A 43-character token would wrap the console. */
    private static String shortToken(String token) {
        return token != null && token.length() > 12 ? token.substring(0, 10) + "..." : token;
    }
}
