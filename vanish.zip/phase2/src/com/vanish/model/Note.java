package com.vanish.model;

import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;

/**
 * A self-destructing secret.
 *
 * The whole design turns on one rule: a note that is finished holds no
 * plaintext. {@link #read()} hands the secret out and, on the last view, drops
 * it; {@link #expireIfDue()} drops it when the clock runs out. So a note whose
 * status says BURNED or EXPIRED cannot still be carrying the secret in memory,
 * and the dashboard label is a fact rather than a claim.
 *
 * This class is NOT thread safe on its own, on purpose. {@code read()} is
 * check-then-act, so two callers could both take the last view. The store owns
 * that problem and solves it by running the whole read inside a single
 * {@code ConcurrentHashMap.compute}, which holds the bin lock for that one
 * token. Putting a lock in here as well would be a second answer to a question
 * that already has one.
 */
public class Note {

    private static final DateTimeFormatter STAMP = DateTimeFormatter.ofPattern("dd-MM-yyyy HH:mm:ss");

    private final int id;
    private final String token;
    private final String owner;
    private final LocalDateTime createdAt;
    private final LocalDateTime expiresAt;

    /** Null once the note is finished. Never leaves this class except via read(). */
    private String text;
    private LocalDateTime readAt;
    private int viewsLeft;
    private boolean burned;

    /**
     * The real constructor: expiry counted in minutes from now.
     *
     * @param text already validated by the service layer
     */
    public Note(int id, String token, String owner, String text, int expiryMinutes, int views) {
        this(id, token, owner, text, LocalDateTime.now(), LocalDateTime.now().plusMinutes(expiryMinutes), views);
    }

    /**
     * Overloaded: exact timestamps. Lets a caller place a note that is already
     * past its expiry, which is how the demo shows the EXPIRED state without
     * waiting out a real clock.
     */
    public Note(int id, String token, String owner, String text,
                LocalDateTime createdAt, LocalDateTime expiresAt, int views) {
        this.id = id;
        this.token = token;
        this.owner = owner;
        this.text = text.trim();
        this.createdAt = createdAt;
        this.expiresAt = expiresAt;
        this.readAt = null;
        this.viewsLeft = views;
        this.burned = false;
    }

    public int getId() {
        return id;
    }

    public String getToken() {
        return token;
    }

    public String getOwner() {
        return owner;
    }

    public LocalDateTime getCreatedAt() {
        return createdAt;
    }

    public LocalDateTime getExpiresAt() {
        return expiresAt;
    }

    public LocalDateTime getReadAt() {
        return readAt;
    }

    public int getViewsLeft() {
        return viewsLeft;
    }

    public boolean isBurned() {
        return burned;
    }

    public boolean isExpired() {
        return LocalDateTime.now().isAfter(expiresAt);
    }

    /**
     * The predicate the store evaluates inside its atomic block. Nothing else
     * should call this and then act on the answer: between the check and the act
     * another thread can take the last view.
     */
    public boolean isReadable() {
        return !burned && !isExpired() && viewsLeft > 0;
    }

    public NoteStatus getStatus() {
        if (burned) {
            return NoteStatus.BURNED;
        }
        if (isExpired()) {
            return NoteStatus.EXPIRED;
        }
        return readAt == null ? NoteStatus.UNREAD : NoteStatus.OPENED;
    }

    public String shareLink() {
        return "/vanish/read?t=" + token;
    }

    /**
     * Hand over the secret and spend one view. Burns and drops the plaintext when
     * that was the last one.
     *
     * The caller MUST have checked {@link #isReadable()} in the same atomic
     * region; this method does not re-check, because a partial guard would look
     * like protection it cannot give.
     *
     * @return the secret, which is the only copy the caller will ever get
     */
    public String read() {
        String secret = text;
        readAt = LocalDateTime.now();
        viewsLeft--;
        if (viewsLeft <= 0) {
            burned = true;
            text = null;
        }
        return secret;
    }

    /**
     * Drop the plaintext of a note that ran out of time.
     *
     * @return true if this call was the one that dropped it, so a sweeper can
     *         report how many notes it actually cleared
     */
    public boolean expireIfDue() {
        if (text != null && isExpired()) {
            text = null;
            return true;
        }
        return false;
    }

    /** True while this note still holds a secret. For the sweeper and for tests. */
    public boolean holdsSecret() {
        return text != null;
    }

    /** One dashboard row. The secret is never part of it. */
    public String dashboardRow() {
        return String.format("  #%-2d  %-11s  %-7s  views=%d  expires %s  read %s",
                id,
                token.length() > 10 ? token.substring(0, 8) + "..." : token,
                getStatus().name(),
                viewsLeft,
                expiresAt.format(STAMP),
                readAt == null ? "-" : readAt.format(STAMP));
    }

    /** Never includes the text. */
    @Override
    public String toString() {
        return "Note[#" + id + " " + getStatus().name() + " owner=" + owner + "]";
    }
}
