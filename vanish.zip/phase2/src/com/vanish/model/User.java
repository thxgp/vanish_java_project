package com.vanish.model;

import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;
import java.security.SecureRandom;
import java.security.spec.InvalidKeySpecException;
import java.time.LocalDateTime;

import javax.crypto.SecretKeyFactory;
import javax.crypto.spec.PBEKeySpec;

/**
 * An account holder.
 *
 * The plaintext password never becomes a field. The constructor hashes it and
 * keeps the salt and the digest; {@link #verify(String)} hashes the attempt and
 * compares. Phase 1 stored the password as a String, which was survivable for a
 * console demo and is not survivable once the store gains the optional file save
 * the README mentions - by then the format is already decided.
 *
 * Instances are immutable, so they are safe to hand to any number of threads.
 */
public final class User {

    private static final String ALGORITHM = "PBKDF2WithHmacSHA256";
    private static final int SALT_BYTES = 16;
    private static final int ITERATIONS = 120_000;
    private static final int KEY_BITS = 256;

    private static final SecureRandom RANDOM = new SecureRandom();

    private final String username;
    private final byte[] salt;
    private final byte[] hash;
    private final LocalDateTime registeredAt;

    /**
     * @param username already validated and trimmed by the service layer
     * @param password plaintext, used once and never retained
     */
    public User(String username, String password) {
        this.username = username.trim();
        this.salt = new byte[SALT_BYTES];
        RANDOM.nextBytes(this.salt);
        this.hash = derive(password, this.salt);
        this.registeredAt = LocalDateTime.now();
    }

    public String getUsername() {
        return username;
    }

    public LocalDateTime getRegisteredAt() {
        return registeredAt;
    }

    /**
     * Constant-time comparison, so the time taken does not leak how many leading
     * bytes of the digest were correct.
     */
    public boolean verify(String password) {
        if (password == null) {
            return false;
        }
        return MessageDigest.isEqual(hash, derive(password, salt));
    }

    /**
     * A fixed-width mask. Phase 1 returned one star per character, which
     * published the length of the password to anyone reading the screen.
     */
    public String maskedPassword() {
        return "********";
    }

    private static byte[] derive(String password, byte[] salt) {
        PBEKeySpec spec = new PBEKeySpec(password.toCharArray(), salt, ITERATIONS, KEY_BITS);
        try {
            return SecretKeyFactory.getInstance(ALGORITHM).generateSecret(spec).getEncoded();
        } catch (NoSuchAlgorithmException | InvalidKeySpecException e) {
            // Both are mandatory in every Java 17 runtime. Reaching here means
            // the JDK is broken, which is not something to recover from by
            // storing a weaker password.
            throw new IllegalStateException("password hashing unavailable", e);
        } finally {
            spec.clearPassword();
        }
    }

    @Override
    public boolean equals(Object other) {
        if (this == other) {
            return true;
        }
        if (!(other instanceof User)) {
            return false;
        }
        return username.equals(((User) other).username);
    }

    @Override
    public int hashCode() {
        return username.hashCode();
    }

    /** Never includes the digest or the salt. */
    @Override
    public String toString() {
        return "User[" + username + "]";
    }
}
