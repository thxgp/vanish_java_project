package com.vanish.model;

/**
 * The four states a note can be in, as one closed set.
 *
 * Phase 1 returned these as strings, which let a typo through the compiler and
 * gave the Phase 4 JSP nothing to switch on. An enum makes the set exhaustive:
 * adding a fifth state breaks every switch that forgot it.
 */
public enum NoteStatus {

    /** Created, never opened, still alive. */
    UNREAD("unread"),

    /** Opened at least once, views still left. Only reachable when views > 1. */
    OPENED("opened"),

    /** Read to exhaustion. The plaintext is gone. */
    BURNED("burned"),

    /** Ran out of time. The plaintext is gone. */
    EXPIRED("expired");

    private final String label;

    NoteStatus(String label) {
        this.label = label;
    }

    /** Lower-case wording for a page or a dashboard row. */
    public String getLabel() {
        return label;
    }

    /** True when the secret is no longer held anywhere. */
    public boolean isFinished() {
        return this == BURNED || this == EXPIRED;
    }
}
